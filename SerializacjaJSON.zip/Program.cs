﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            var studenci = new List<Student>()
            {
                new Student()
                {
                    IndexNumber = "s1234",
                    FirstName = "Jan",
                    LastName = "Kowalski",
                    BirthDate = DateTime.Parse("02.05.1980").ToShortDateString(),
                    Email = "kowalski@wp.pl",
                    MothersName = "Alina",
                    FatherName = "Jan",
                    Studies = new Studies()
                    {
                        Name = "Computer Science",
                        Mode = "Dzienne"
                    }
                },
                new Student()
                {
                    IndexNumber = "s2432",
                    FirstName = "Anna",
                    LastName = "Malewska",
                    BirthDate = DateTime.Parse("07.10.1985").ToShortDateString(),
                    Email = "malewska@wp.pl",
                    MothersName = "Marta",
                    FatherName = "Marcin",
                    Studies = new Studies()
                    {
                        Name = "New Media Art",
                        Mode = "Zaoczne"
                    }
                }
            };

            var uczelnia = new Uczelnia() { Studenci = studenci, Author = "Jan Kowalski" };
            var options = new JsonSerializerOptions { WriteIndented = true, PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
            string jsonString = JsonSerializer.Serialize(new { Uczelnia = uczelnia }, options);
            await File.WriteAllTextAsync("result.json", jsonString);
        }
    }
}
